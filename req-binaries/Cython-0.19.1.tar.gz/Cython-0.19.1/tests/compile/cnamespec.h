int c_a, c_b;
