Tutorials
=========

.. toctree::
   :maxdepth: 2

   external
   clibraries
   cdef_classes
   pxd_files
   caveats
   profiling_tutorial
   strings
   pure
   numpy
   readings
   related_work
   appendix

